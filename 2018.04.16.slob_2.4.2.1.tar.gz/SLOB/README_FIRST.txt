
Helpful information and current SLOB software is available at http://kevinclosson.net/slob


License Info          : LICENSE.txt
Release Description   : RELEASE.txt
Release Specifics     : RELEASE_NOTES.txt
Local Documentation   : doc/SLOB_UserGuide_2.4.0.pdf
